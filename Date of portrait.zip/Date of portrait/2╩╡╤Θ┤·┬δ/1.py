# 导入包
import re
import xlrd
import xlwt
import jieba
import jieba.analyse
jieba.load_userdict('图情专业词典-用于分词/图情专业词典-用于分词.txt') # 导入自定义的词典到jieba，用于分词
from bert_serving.client import BertClient #wordvct_list=BertClient().encode(['美丽','漂亮'])  # 需在CMD中执行右侧两条命令以激活’bert-serving-start‘，且不要关闭本CMD，然后使用之后几行命令获取词向量：（cd C:\Users\balibala\AppData\Local\Programs\Python\Python37\Scripts）、（bert-serving-start  -model_dir D:\jupyterfiles\chinese_L-12_H-768_A-12）
# 建立停用词列表
stopword_list = []
with open('C:/Users/balibala/WeihuapinBentiGoujian/urlspider/分词用词表/百度停用词表.txt', 'r', encoding='utf-8') as s:
    for line in s:
        if len(line)>0:
            stopword_list.append(line.strip())
with open('C:/Users/balibala/WeihuapinBentiGoujian/urlspider/分词用词表/哈工大停用词表.txt', 'r', encoding='utf-8') as s:
    for line in s:
        if len(line)>0:
            stopword_list.append(line.strip())
with open('C:/Users/balibala/WeihuapinBentiGoujian/urlspider/分词用词表/四川大学停用词表.txt', 'r', encoding='utf-8') as s:
    for line in s:
        if len(line)>0:
            stopword_list.append(line.strip())
with open('C:/Users/balibala/WeihuapinBentiGoujian/urlspider/分词用词表/中文停用词库.txt', 'r', encoding='utf-8') as s:
    for line in s:
        if len(line)>0:
            stopword_list.append(line.strip())
with open('C:/Users/balibala/WeihuapinBentiGoujian/urlspider/分词用词表/自建百度百科专用停用词表.txt', 'r', encoding='utf-8') as s:
    for line in s:
        if len(line)>0:
            stopword_list.append(line.strip())
# 构建向量相似度函数
def cos(x,y):
    r1 = 0.0;r2 = 0.0;r3 = 0.0
    for i in range(len(x)):
        r1 = r1 + x[i] * y[i]; r2= r2 + x[i] ** 2; r3= r3 + y[i] ** 2
    if (r2 * r3) ** 0.5 != 0:
        return r1/((r2 * r3) ** 0.5)
    else:
        return 0

#标签构建———————————————————————————————————————————————————————————————————————————————————————————————————————————————
doc_list = []  #储存所有预处理后的文本，用于最后的LDA聚类
author_list=[] #储存所有作者的标签词，用于作者领域排名，每个元素为一个作者。为一三层嵌套列表
for i in range(20):     #处理作者i(共20位)
    print('\n作者',i,'-------------------------------------------------------------------------------------------')
    path='{}.xls' #作者论文数据路径
    path1=path.format(str(i))
    # print(path1)
    workbook = xlrd.open_workbook(path1) #打开从知网下载的作者论文数据excel文件
    sheet = workbook.sheet_by_index(0) #获取工作表sheet
    exec('author%s=[]' % i) #为作者i建立列表，用于存储其所有论文的结果

    # 创建文件以保存作者论文处理结果的数据
    workbook = xlwt.Workbook(encoding='utf-8')
    worksheet = workbook.add_sheet('My Worksheet', cell_overwrite_ok=True)
    worksheet.write(0, 0, label='标题')
    worksheet.write(0, 1, label='关键词')
    worksheet.write(0, 2, label='摘要')
    worksheet.write(0, 3, label='分词后')
    worksheet.write(0, 4, label='去停用词后')


    for j in range(1,sheet.nrows):    #处理作者i的论文j sheet.nrows
        print('论文',j,'......')
        #1 捕获某论文j的摘要等数据、分词、过滤停用词：
        #1.1 捕获文件
        content = sheet.cell_value(j,1)*3 + sheet.cell_value(j,5)*3 + sheet.cell_value(j,6) #取出工作表中标题、关键词、摘要字符串并合并
        content = content.replace(' ', '') #清除空格
        content = re.sub('\(.*?\)', ',', content) #去除括号及括号内的内容
        worksheet.write(j*7-6, 0, label=sheet.cell_value(j,1))
        worksheet.write(j*7-5, 0, label=j)
        worksheet.write(j*7-6, 1, label=sheet.cell_value(j,5))
        worksheet.write(j*7-6, 2, label=sheet.cell_value(j,6))
        # print('\n\n初始文本=',content)

        #1.2 分词
        content = jieba.cut(content,cut_all=False) # 分词（得到的是一个生成器对象）
        content1 = []  # 以下为了输出/打印分词结果
        for w in content:
            content1.append(w)
        content = ' '.join(content1) # 词间加入空格并由列表转为字符串
        worksheet.write(j*7-6,3, label=content)
        # print('分词后=',content)

        #1.3 删除停用词、删除两个字的词(多为动词)
        content2 = []
        for w in content1:
            if w not in stopword_list and len(w)>2:
                content2.append(w)
        content = ' '.join(content2) # 词间加入空格并由列表转为字符串
        content_list = content.split()
        doc_list.append(content_list)
        worksheet.write(j*7-6, 4, label=content)
        # print('去停用词后=', content)


        #2 获取某一论文的候选词（词k、词K的tf-idf值分别存于keywords_list[k][0]、keywords_list[k][1]）
        keywords_list = jieba.analyse.extract_tags(content, topK=20, withWeight=True, allowPOS=('n','nr','ns','nt','nz'))  #'n','nr','ns'
        # print(keywords_list)
        # for k in range(len(keywords_list)):
            # print(keywords_list[k][0])


        #3 使用BERT获取词向量（得到包含向量的词表  词k的向量存于keyvec_list[k][2]）
        keyvec_list=[]
        for k in range(len(keywords_list)):
            word=[]
            wordvec=BertClient().encode([keywords_list[k][0]])
            # print(wordvec[0])
            word.append(keywords_list[k][0])
            word.append(keywords_list[k][1])
            word.append(wordvec[0])
            keyvec_list.append(word)


        #4 计算每个词的相对权值 （词k）（即归一化后的加权相似度，并存于keyvec_list[k][4]）
        sum_weight = 0.0 #用于归一化
        for k in range(len(keywords_list)):     #计算加权相似度，并乘以TFIDF值，然后存于keyvec_list[k][3]
            weight_k = 0.0
            for l in range(len(keywords_list)):
                sim_kl = (keyvec_list[k][1] + keyvec_list[l][1])* cos(keyvec_list[k][2], keyvec_list[l][2]) # 加权相似度
                weight_k += sim_kl
            keyvec_list[k].append(weight_k) #存于keyvec_list[k][3]
            sum_weight += weight_k
        for k in range(len(keywords_list)):  #权值归一化后存于keyvec_list[k][4]
            weight_k = keyvec_list[k][3] / sum_weight
            keyvec_list[k].append(weight_k)

        #5 根据相对权值的大小进行筛选  (筛选后得到keyvec_list1)
        keyvec_list1=[]
        for k in range(len(keyvec_list)):
            if keyvec_list[k][4] >= 0.04:
                keyvec_list1.append(keyvec_list[k])


        #6 计算绝对权值 （即相对权值乘以论文权值，并存于keyvec_list[k][5]）
        y = float(sheet.cell_value(j,16))+float(sheet.cell_value(j,17)) # y为期刊影响因子
        for k in range(len(keyvec_list1)):
            must_weight_k = keyvec_list1[k][4]*y
            keyvec_list1[k].append(must_weight_k)
            worksheet.write(j * 7 - 5, 6 , label='标签词')
            worksheet.write(j * 7 - 4, 6 , label='TF-IDF')
            worksheet.write(j * 7 - 3, 6 , label='相对权值（未归一化）（加权相似度）')
            worksheet.write(j * 7 - 2, 6 , label='相对权值（归一化后）')
            worksheet.write(j * 7 - 1, 6 , label='绝对权值')
            worksheet.write(j * 7 - 5, 7+k, label=keyvec_list1[k][0])
            worksheet.write(j * 7 - 4, 7 + k, label=keyvec_list1[k][1])
            worksheet.write(j * 7 - 3, 7 + k, label=keyvec_list1[k][3])
            worksheet.write(j * 7 - 2, 7 + k, label=keyvec_list1[k][4])
            worksheet.write(j * 7 - 1, 7+k, label=must_weight_k)
            exec('author%s.append(keyvec_list1[k])' % i)  # 保存作者i的数据


        #7 聚类

        #8 保存/输出
        # for k in range(len(keyvec_list1)):
        #     print(keyvec_list1[k][0],keyvec_list1[k][1],keyvec_list1[k][3],keyvec_list1[k][4],keyvec_list1[k][5])
        #
        # print('000000000000000000000000000000000000000000000000000000000000000000')
        # print('\n')
        # for k in range(len(keyvec_list1)):
        #     print(keyvec_list1[k][0])
        # print('\n\n')
        #
        # print('555555555555555555555555555555555555555555555555555555555555555555555555')
        # for k in range(len(keyvec_list1)):
        #     print(keyvec_list1[k][5])

    exec("workbook.save('%s(过程数据).xls')" % i)#过程数据表格文件保存
    exec('author_list.append(author%s)' % i)  #储存所有作者的标签词
    # "workbook.save('%s(过程数据).xls')"%i

    # exec('print(author%s)' % i)  # 打印作者i的数据
    # exec("for k in range(len(author%s)): print(author%s[k][0])" % (i,i))
    # exec("for k in range(len(author%s)): print(author%s[k][5])" % (i,i))


#领域排名________________________________________________________________________________________________________________
#1 领域划分（使用LDA聚类的方法）
n = 40 #聚几类
#1.1 构建文档-词项矩阵
import gensim
from gensim import corpora
# print(doc_list)
dictionary = corpora.Dictionary(doc_list)# 创建语料的词语词典，每个单独的词语都会被赋予一个索引
doc_term_matrix = [dictionary.doc2bow(doc) for doc in doc_list]# 使用上面的词典，将转换文档列表（语料）变成 DT 矩阵
# print('\n文本-词项矩阵:\n',doc_term_matrix)

#1.2使用gensim来创建lda模型
lda = gensim.models.ldamodel.LdaModel(doc_term_matrix, num_topics=n,id2word = dictionary, passes=50)# 在DT矩阵上运行和训练LDA模型 (n_iter = 1500,迭代1500次)

#1.3 输出：主题的词项分布，n个主题，每个主题由5个词表示
print('\n主题的词项分布：\n',lda.print_topics(num_topics=n))
fr = open('LDA聚类结果(领域划分).txt','w+')
fr.write('主题的词项分布：\n' + str(lda.print_topics(num_topics=n)))


#2 作者排名（构建领域-作者矩阵）
#2.1 LDA结果转化为三层嵌套列表（[[[权值，词]，[权值，词]...],[第二个主题]...]）
topic_list = []
topic0 = lda.print_topics(num_topics=n)
for i in range(n):
    topic = topic0[i][1]
    topic = topic.split('" + ')
    top = []
    for j in range(len(topic)):
        topic1 = topic[j]
        topic1 = topic1.split('*"')
        top.append(topic1)
    topic_list.append(top)

#2.2 构建主题-作者矩阵并储存
workbook = xlwt.Workbook(encoding = 'utf-8')
worksheet = workbook.add_sheet('My Worksheet',cell_overwrite_ok=True)
worksheet.write(0, 0, label='作者')
for i in range(n): #对于第i个主题
    for k in range(len(author_list)): #对于第k个作者
        num = 0.0
        for j in range(len(topic_list[i])):  # 对于第i个主题的第j个词
            for l in range(len(author_list[k])): #对于第k个作者的第l个词
                if topic_list[i][j][1] == author_list[k][l][0]:
                    num = num + float(topic_list[i][j][0]) * float(author_list[k][l][5]) * 10
        worksheet.write(k+1, i+1,label=num)

#*保存结果
for i in range(n): #保存每个主题的构成
    worksheet.write(0, i + 1, label=lda.print_topics(num_topics=n)[i][1])
for k in range(len(author_list)): #保存每个作者的标签词构成
    for d in range (len(author_list[k])):
        worksheet.write(d+1, n+5+4*k, label=author_list[k][d][0])
        worksheet.write(d+1, n+6+4*k, label=author_list[k][d][5])

workbook.save('主题-作者矩阵.xls')